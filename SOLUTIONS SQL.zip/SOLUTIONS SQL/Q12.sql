-- Q12 Analyze the cumulative revenue generated over time.

SELECT 
order_date,
ROUND(sum(revenue) over(order by order_date),1) as cumrev
FROM
(SELECT
orders.order_date,
sum(order_details.quantity*pizzas.price) as revenue
FROM
orders JOIN order_details
ON orders.order_id=order_details.order_id
JOIN pizzas
ON order_details.pizza_id=pizzas.pizza_id
group by orders.order_date) as sales;